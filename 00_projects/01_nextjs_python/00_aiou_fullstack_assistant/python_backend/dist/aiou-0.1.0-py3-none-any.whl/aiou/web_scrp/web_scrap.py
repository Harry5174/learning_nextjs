import requests
from bs4 import BeautifulSoup
import pdfkit
import openai
import os

async def scrap_webtest(url):
    response = requests.get(url, verify=False)
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, "html.parser")
        return soup.get_text()
    else:
        return None

def clean_data(data):
    # Implement data cleaning logic here
    # For example, remove extra whitespace, special characters, etc.
    cleaned_data = data.strip()  # Remove leading and trailing whitespace
    cleaned_data = cleaned_data.replace('\n', ' ')  # Replace newline characters with spaces
    return cleaned_data

# filepath = os.path.join(os.path.dirname(__file__), '..', 'assets', 'data.pdf')

def text_to_pdf(text):
    file_path = os.path.join(os.path.dirname(__file__), '..', 'assets', 'data.pdf')
    path_wkhtmltopdf = '/usr/bin/wkhtmltopdf'  # Path to the wkhtmltopdf binary
    pdfkit.from_string(text, file_path, configuration=pdfkit.configuration(wkhtmltopdf=path_wkhtmltopdf))
    return file_path

def upload_to_openai(filepath, client):
    with open(filepath,"rb")as file:
        print(f'file path{filepath}')
        response=client.files.create(file=file.read(),purpose="assistants")
        print(response.id)
    return response.id

# vector_store_id = 

# from ..routes.main_routes import assistant_id
# async def upload_to_assistant(client):
#     # data_file_path = os.path.join(assets_folder, 'data.pdf')
#     assistant = client.beta.assistants.update(
#     assistant_id=assistant_id,
#     tool_resources={"file_search": {"vector_store_ids": [vector_store_id]}},
#     )

# from ..routes.main_routes import assistant_id
# async def upload_to_openai(client, filepath):
#     try:
#         with open(filepath, "rb") as file:
#             uploaded_file = client.files.create(file=file, purpose='assistants')

#              # Add the uploaded file to the assistant
#             response = client.beta.assistants.files.create(assistant_id=assistant_id, file_id=uploaded_file.id)

#             print(f"Uploaded file to OpenAI! File ID: {response.id}")
#             return response.id
#     except FileNotFoundError:
#         print(f"File not found: {filepath}")
#         return None

# async def upload_to_openai(client):
#     try:
#         filepath = os.path.join(os.path.dirname(__file__), '..', 'assets', 'data.pdf')
#         if not os.path.exists(filepath):
#             raise FileNotFoundError(f"File not found: {filepath}")
        
#         with open(filepath, "rb") as file:
#             # Upload the file to OpenAI
#             uploaded_file = client.files.create(file=file, purpose='assistants')

#             # Add the uploaded file to the assistant
#             response = client.beta.assistants.files.create(assistant_id=assistant_id, file_id=uploaded_file.id)

#             print(f"Uploaded file to OpenAI! File ID: {response.id}")
#             return response.id
#     except FileNotFoundError as e:
#         print(e)
#         return None