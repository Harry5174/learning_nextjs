import subprocess
from ..openai.openai_connectivity import OPENAI_API_KEY

# Define the cURL command
curl_command = [
    'curl',
    '-X', 'GET',
    '-H', 'Authorization: Bearer {OPENAI_API_KEY}',
    'https://api.openai.com/v1/files'
]

# Execute the cURL command
process = subprocess.Popen(curl_command, stdout=subprocess.PIPE)

# Get the output of the command
output, error = process.communicate()

# Print the output
print(output.decode('utf-8'))
